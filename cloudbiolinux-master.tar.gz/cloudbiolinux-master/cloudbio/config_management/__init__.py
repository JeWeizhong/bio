""" This module contains code related to integrating the configuration
management tools `chef` and `puppet` into CloudBioLinux. """

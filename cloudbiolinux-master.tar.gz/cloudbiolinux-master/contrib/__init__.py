"""Module containing user contributions
"""

"""Neuroinformatics flavor
"""

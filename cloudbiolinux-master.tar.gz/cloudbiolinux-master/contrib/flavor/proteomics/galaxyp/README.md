This directory contains a stand-alone (no CloudMan) Galaxy-P flavor
for installing Galaxy-P in desktop or cluster environments. If
configuring Galaxy-P for cloud based enviornments, the
cloudman/cloudman_and_galaxyp flavor is likely a more appropriate target.

For more information on using CloudBioLinux to install Galaxy-P, please see
http://getgalaxyp.org/install.html.

Small example flavor to demonstrate ability to provide local installations

"""Pjotr's flavors"""

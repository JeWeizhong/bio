Full hg38/GRCh38 reference genome distributed by 1000 genomes
Derived from NCBI set with HLA and decoy alternative alleles
http://ftp.1000genomes.ebi.ac.uk/vol1/ftp/technical/reference/GRCh38_reference_genome/

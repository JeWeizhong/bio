Recipes for downloading data

Idea developed from Aaron Quinlan's GGD (Get Genomic Data)

https://github.com/arq5x/ggd
https://github.com/arq5x/ggd-recipes
